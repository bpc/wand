""":mod:`wand` --- Simple `MagickWand API`_ binding for Python
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. _MagickWand API: http://www.imagemagick.org/script/magick-wand.php

"""

